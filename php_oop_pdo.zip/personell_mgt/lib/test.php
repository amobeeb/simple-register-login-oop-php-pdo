<?php 
$a = 1;
if($a==1):
	echo "Checked";
endif;




 ?>